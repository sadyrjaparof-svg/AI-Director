#!/usr/bin/env python3
"""
Seedance Master Skill 验证脚本
验证提示词格式、敏感词检查、Skill 结构等
"""

import sys
import re
from pathlib import Path


SENSITIVE_WORDS = {
    "江湖人士": "武者",
    "武林人士": "习武之人",
    "杀": "击败",
    "死": "倒下",
    "血腥": "受伤",
}

FORBIDDEN_FILES = ["README.md", "CHANGELOG.md", "INSTALLATION.md", "INSTALLATION_GUIDE.md", "QUICK_REFERENCE.md"]

ALLOWED_PROPERTIES = {'name', 'description', 'license', 'allowed-tools', 'metadata'}


def validate_prompt(prompt: str) -> tuple:
    """
    验证 Seedance 提示词
    
    Returns:
        (is_valid, issues)
    """
    issues = []
    
    sensitive_found = []
    for word in SENSITIVE_WORDS:
        if word in prompt:
            sensitive_found.append(f"'{word}' → 建议替换为 '{SENSITIVE_WORDS[word]}'")
    
    if sensitive_found:
        issues.append(f"发现敏感词 / Sensitive words: {', '.join(sensitive_found)}")
    
    if len(prompt) > 2000:
        issues.append(f"提示词过长 / Prompt too long ({len(prompt)} chars)，建议拆分为时间线分段写法")
    
    time_segments = re.findall(r'(\d+-\d+s画面)', prompt)
    if time_segments:
        total_time = 0
        for seg in time_segments:
            match = re.match(r'(\d+)-(\d+)s', seg)
            if match:
                end = int(match.group(2))
                if end > total_time:
                    total_time = end
        if total_time > 15:
            issues.append(f"视频时长 / Video duration {total_time}s 超出限制（最大15秒 / max 15s）")
    
    return len(issues) == 0, issues


def validate_timeline_format(prompt: str) -> tuple:
    """
    验证时间线分段格式
    
    分段规则 / Segmentation rules:
    - ≤10秒: 3段
    - 11-20秒: 4段
    - >20秒: 5段
    """
    issues = []
    
    time_segments = re.findall(r'(\d+-\d+s画面)', prompt)
    
    if not time_segments:
        return True, issues
    
    total_time = 0
    for seg in time_segments:
        match = re.match(r'(\d+)-(\d+)s', seg)
        if match:
            end = int(match.group(2))
            if end > total_time:
                total_time = end
    
    if total_time <= 10:
        expected_segments = 3
    elif total_time <= 20:
        expected_segments = 4
    else:
        expected_segments = 5
    
    if len(time_segments) > expected_segments:
        issues.append(f"分段过多 / Too many segments ({len(time_segments)}段)，{total_time}秒视频建议{expected_segments}段，避免动作变形和场景跳变")
    
    hook_pattern = r'0-\d+s画面：.*【黄金3秒'
    if time_segments and not re.search(hook_pattern, prompt):
        issues.append("建议在第一段画面添加黄金3秒钩子设计 / Consider adding Golden 3-second hook in first segment")
    
    return len(issues) == 0, issues


def validate_material_reference(prompt: str) -> tuple:
    """
    验证素材引用语法
    """
    issues = []
    refs = re.findall(r'@图片\d+|@视频\d+|@音频\d+', prompt)
    return len(issues) == 0, issues


def validate_skill_structure(skill_path: str) -> tuple:
    """
    验证 skill 目录结构
    """
    issues = []
    skill_path = Path(skill_path)
    
    required_files = ["SKILL.md"]
    for f in required_files:
        if not (skill_path / f).exists():
            issues.append(f"缺少必需文件 / Missing required file: {f}")
    
    for f in FORBIDDEN_FILES:
        if (skill_path / f).exists():
            issues.append(f"发现禁止文件 / Forbidden file: {f} - 请删除 / Please delete")
    
    recommended_dirs = ["references"]
    for d in recommended_dirs:
        if not (skill_path / d).exists():
            pass
    
    return len(issues) == 0, issues


def main():
    if len(sys.argv) < 2:
        print("用法 / Usage: python validate.py <skill_directory|prompt_file>")
        print("\n验证模式 / Validation modes:")
        print("  python validate.py <skill_dir>     - 验证 skill 结构 / Validate skill structure")
        print("  python validate.py --prompt <file> - 验证提示词文件 / Validate prompt file")
        sys.exit(1)
    
    if sys.argv[1] == "--prompt" and len(sys.argv) >= 3:
        prompt_file = Path(sys.argv[2])
        if not prompt_file.exists():
            print(f"错误 / Error: 文件不存在 / File not found {prompt_file}")
            sys.exit(1)
        
        prompt = prompt_file.read_text(encoding='utf-8')
        
        print("=" * 50)
        print("Seedance 提示词验证报告 / Prompt Validation Report")
        print("=" * 50)
        
        valid1, issues1 = validate_prompt(prompt)
        valid2, issues2 = validate_timeline_format(prompt)
        valid3, issues3 = validate_material_reference(prompt)
        
        all_issues = issues1 + issues2 + issues3
        
        if all_issues:
            print("\n⚠️ 发现以下问题 / Issues found:\n")
            for issue in all_issues:
                print(f"  - {issue}")
        else:
            print("\n✅ 提示词验证通过 / Prompt validation passed!")
        
        sys.exit(0 if not all_issues else 1)
    
    else:
        skill_path = sys.argv[1]
        
        print("=" * 50)
        print("Seedance Master Skill 结构验证 / Structure Validation")
        print("=" * 50)
        
        valid, issues = validate_skill_structure(skill_path)
        
        if issues:
            print("\n⚠️ 发现以下问题 / Issues found:\n")
            for issue in issues:
                print(f"  - {issue}")
        else:
            print("\n✅ Skill 结构验证通过 / Skill structure validation passed!")
        
        sys.exit(0 if valid else 1)


if __name__ == "__main__":
    main()
